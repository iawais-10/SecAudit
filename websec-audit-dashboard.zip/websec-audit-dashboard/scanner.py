import requests
import socket
import ssl
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urlunparse, urlencode, parse_qsl
import tldextract
from datetime import datetime

DEFAULT_TIMEOUT = 12

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
]

INFO_DISCLOSURE_HEADERS = [
    "Server",
    "X-Powered-By",
    "X-AspNet-Version",
    "X-AspNetMvc-Version",
]

SENSITIVE_PATHS = [
    "/.env",
    "/.git/",
    "/admin",
    "/login",
    "/phpinfo.php",
    "/robots.txt",
    "/sitemap.xml",
]

DIR_LISTING_PATHS = [
    "/uploads/",
    "/backup/",
    "/logs/",
    "/images/",
]

def normalize_url(url: str) -> str:
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url

def host_from_url(url: str) -> str:
    p = urlparse(url)
    return p.hostname or ""

def is_ip(host: str) -> bool:
    try:
        socket.inet_aton(host)
        return True
    except OSError:
        return False

def safe_get(url: str, allow_redirects=True):
    return requests.get(url, timeout=DEFAULT_TIMEOUT, allow_redirects=allow_redirects, headers={
        "User-Agent": "WebSecAuditDashboard/1.0 (Educational)"
    })

def safe_options(url: str):
    return requests.options(url, timeout=DEFAULT_TIMEOUT, allow_redirects=True, headers={
        "User-Agent": "WebSecAuditDashboard/1.0 (Educational)"
    })

def check_https_redirect_and_hsts(url: str):
    """
    - Checks if http:// redirects to https://
    - Checks if HSTS is present on https response
    """
    parsed = urlparse(url)
    host = parsed.hostname
    if not host:
        return {"status": "ERROR", "details": "Invalid URL"}

    http_url = urlunparse(("http", host, parsed.path or "/", "", parsed.query, ""))
    https_url = urlunparse(("https", host, parsed.path or "/", "", parsed.query, ""))

    result = {
        "http_to_https_redirect": {"status": "UNKNOWN", "details": ""},
        "hsts": {"status": "UNKNOWN", "details": ""},
    }

    try:
        r_http = safe_get(http_url, allow_redirects=True)
        final_scheme = urlparse(r_http.url).scheme
        if final_scheme == "https":
            result["http_to_https_redirect"] = {"status": "PASS", "details": f"Redirects to {r_http.url}"}
        else:
            result["http_to_https_redirect"] = {"status": "WARN", "details": f"Final URL is {r_http.url}"}
    except Exception as e:
        result["http_to_https_redirect"] = {"status": "ERROR", "details": str(e)}

    try:
        r_https = safe_get(https_url, allow_redirects=True)
        hsts_val = r_https.headers.get("Strict-Transport-Security")
        if hsts_val:
            result["hsts"] = {"status": "PASS", "details": hsts_val}
        else:
            result["hsts"] = {"status": "FAIL", "details": "Strict-Transport-Security header missing"}
    except Exception as e:
        result["hsts"] = {"status": "ERROR", "details": str(e)}

    return result

def check_security_headers(url: str):
    """
    Audit presence of common security headers on the main response.
    """
    findings = []
    try:
        r = safe_get(url, allow_redirects=True)
        headers = r.headers

        for h in SECURITY_HEADERS:
            if h in headers and headers.get(h):
                findings.append({"header": h, "status": "PASS", "details": headers.get(h)})
            else:
                findings.append({"header": h, "status": "FAIL", "details": "Missing"})
        return {"status": "OK", "findings": findings, "final_url": r.url}
    except Exception as e:
        return {"status": "ERROR", "error": str(e), "findings": []}

def check_cookie_flags(url: str):
    """
    Check Set-Cookie flags: Secure, HttpOnly, SameSite.
    """
    results = []
    try:
        r = safe_get(url, allow_redirects=True)
        set_cookie = r.headers.get("Set-Cookie")
        if not set_cookie:
            return {"status": "OK", "cookies_found": False, "findings": [{"status": "WARN", "details": "No Set-Cookie header found"}]}

        # Some servers return multiple Set-Cookie headers; requests merges sometimes.
        # We'll do a simple parse by splitting on ", " only when it looks safe is hard.
        # For an academic project, flag presence per cookie string segment.
        cookie_lines = r.raw.headers.get_all("Set-Cookie") if hasattr(r.raw, "headers") else [set_cookie]

        for c in cookie_lines:
            flags = c.lower()
            results.append({
                "cookie": c,
                "Secure": "secure" in flags,
                "HttpOnly": "httponly" in flags,
                "SameSite": ("samesite=" in flags),
                "status": "PASS" if ("secure" in flags and "httponly" in flags and "samesite=" in flags) else "WARN",
            })

        return {"status": "OK", "cookies_found": True, "findings": results}
    except Exception as e:
        return {"status": "ERROR", "error": str(e), "findings": []}

def check_info_disclosure_headers(url: str):
    """
    Detect headers that may disclose server/framework details.
    """
    findings = []
    try:
        r = safe_get(url, allow_redirects=True)
        for h in INFO_DISCLOSURE_HEADERS:
            if r.headers.get(h):
                findings.append({"header": h, "status": "WARN", "details": r.headers.get(h)})
            else:
                findings.append({"header": h, "status": "PASS", "details": "Not present"})
        return {"status": "OK", "findings": findings}
    except Exception as e:
        return {"status": "ERROR", "error": str(e), "findings": []}

def check_sensitive_paths(url: str):
    """
    Check whether common sensitive paths are accessible.
    Only GET requests; no auth, no fuzzing, no brute-force.
    """
    parsed = urlparse(url)
    base = urlunparse((parsed.scheme, parsed.netloc, "", "", "", ""))

    findings = []
    for p in SENSITIVE_PATHS:
        target = base + p
        try:
            r = safe_get(target, allow_redirects=True)
            status = r.status_code
            if status == 200 and p not in ["/robots.txt", "/sitemap.xml"]:
                findings.append({"path": p, "status": "WARN", "http_status": status, "details": "Accessible (review content exposure)"})
            else:
                findings.append({"path": p, "status": "PASS", "http_status": status, "details": "Not directly exposed / not accessible"})
        except Exception as e:
            findings.append({"path": p, "status": "ERROR", "details": str(e)})

    return {"status": "OK", "findings": findings}

def check_http_methods(url: str):
    """
    Enumerate allowed methods via OPTIONS and warn on risky methods.
    """
    risky = {"PUT", "DELETE", "TRACE", "TRACK"}
    try:
        r = safe_options(url)
        allow = r.headers.get("Allow", "")
        allowed = [m.strip().upper() for m in allow.split(",") if m.strip()] if allow else []
        risky_found = sorted(list(set(allowed) & risky))

        if risky_found:
            return {"status": "WARN", "allowed": allowed, "risky": risky_found, "details": "Risky methods enabled"}
        return {"status": "PASS", "allowed": allowed, "risky": [], "details": "No risky methods detected (from Allow header)"}
    except Exception as e:
        return {"status": "ERROR", "error": str(e), "allowed": [], "risky": []}

def check_directory_listing(url: str):
    """
    Detect directory listing indicators on common directories.
    """
    parsed = urlparse(url)
    base = urlunparse((parsed.scheme, parsed.netloc, "", "", "", ""))

    findings = []
    indicators = ["index of /", "<title>index of", "directory listing for", "apache/"]

    for p in DIR_LISTING_PATHS:
        target = base + p
        try:
            r = safe_get(target, allow_redirects=True)
            text = (r.text or "").lower()
            if r.status_code == 200 and any(ind in text for ind in indicators):
                findings.append({"path": p, "status": "FAIL", "http_status": r.status_code, "details": "Directory listing detected"})
            else:
                findings.append({"path": p, "status": "PASS", "http_status": r.status_code, "details": "No directory listing detected"})
        except Exception as e:
            findings.append({"path": p, "status": "ERROR", "details": str(e)})

    return {"status": "OK", "findings": findings}

def check_reflected_input(url: str):
    """
    Very basic reflected input check:
    - Append a benign parameter and see if it appears in the response.
    """
    marker = "websec_audit_test_12345"
    try:
        parsed = urlparse(url)
        q = dict(parse_qsl(parsed.query, keep_blank_values=True))
        q["audit"] = marker
        new_query = urlencode(q)

        test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path or "/", parsed.params, new_query, parsed.fragment))
        r = safe_get(test_url, allow_redirects=True)

        body = r.text or ""
        reflected = marker in body

        if reflected:
            return {"status": "WARN", "test_url": test_url, "details": "Input reflected in response (review encoding/escaping)"}
        return {"status": "PASS", "test_url": test_url, "details": "No reflection detected"}
    except Exception as e:
        return {"status": "ERROR", "error": str(e)}

def check_tls_certificate(url: str):
    """
    Lightweight TLS cert check: expiry + subject/issuer (if HTTPS).
    """
    parsed = urlparse(url)
    host = parsed.hostname
    if not host:
        return {"status": "ERROR", "details": "Invalid URL"}

    if parsed.scheme != "https":
        return {"status": "WARN", "details": "URL is not HTTPS; TLS check skipped"}

    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.socket(socket.AF_INET), server_hostname=host) as s:
            s.settimeout(DEFAULT_TIMEOUT)
            s.connect((host, 443))
            cert = s.getpeercert()

        not_after = cert.get("notAfter")
        subject = cert.get("subject")
        issuer = cert.get("issuer")

        return {
            "status": "PASS",
            "notAfter": not_after,
            "subject": subject,
            "issuer": issuer
        }
    except Exception as e:
        return {"status": "ERROR", "error": str(e)}

def run_scan(url: str) -> dict:
    url = normalize_url(url)

    host = host_from_url(url)
    ext = tldextract.extract(host) if host else None

    report = {
        "meta": {
            "generated_at_utc": datetime.utcnow().isoformat() + "Z",
            "tool": "WebSecAuditDashboard",
            "version": "1.0"
        },
        "target": {
            "input_url": url,
            "host": host,
            "domain": f"{ext.domain}.{ext.suffix}" if ext and ext.suffix else host,
        },
        "checks": {}
    }

    # Run checks
    report["checks"]["security_headers_audit"] = check_security_headers(url)
    report["checks"]["https_redirect_and_hsts"] = check_https_redirect_and_hsts(url)
    report["checks"]["cookie_flag_analysis"] = check_cookie_flags(url)
    report["checks"]["information_disclosure_headers"] = check_info_disclosure_headers(url)
    report["checks"]["sensitive_path_accessibility"] = check_sensitive_paths(url)
    report["checks"]["http_methods_enumeration"] = check_http_methods(url)
    report["checks"]["directory_listing_detection"] = check_directory_listing(url)
    report["checks"]["basic_reflected_input_check"] = check_reflected_input(url)
    report["checks"]["tls_certificate_check"] = check_tls_certificate(url)

    return report
