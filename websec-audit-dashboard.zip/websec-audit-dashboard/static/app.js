window.addEventListener("DOMContentLoaded", () => {
  const overlay = document.getElementById("overlay");
  const btnSpinner = document.querySelector(".btnSpinner");
  const runBtn = document.getElementById("runBtn");

  // Force-hide loader on initial load
  if (overlay) overlay.classList.add("hidden");
  if (btnSpinner) btnSpinner.classList.add("hidden");
  if (runBtn) runBtn.disabled = false;
});




const runBtn = document.getElementById("runBtn");
const urlInput = document.getElementById("url");
const statusBox = document.getElementById("status");
const resultsBox = document.getElementById("results");

const scoreBox = document.getElementById("scoreBox");
const ratingBox = document.getElementById("ratingBox");
const downloadBox = document.getElementById("downloadBox");
const summaryBox = document.getElementById("summary");
const detailsBox = document.getElementById("details");
const deductionsBox = document.getElementById("deductionsBox");

const overlay = document.getElementById("overlay");
const btnSpinner = document.querySelector(".btnSpinner");

const CHECK_INFO = {
  security_headers_audit: {
    title: "Security headers audit",
    desc: "Checks presence of key security headers like CSP, HSTS, X-Frame-Options and others. Missing headers can increase risk of clickjacking, XSS and content injection."
  },
  https_redirect_and_hsts: {
    title: "HTTPS redirect + HSTS",
    desc: "Verifies HTTP redirects to HTTPS and checks HSTS to enforce secure connections and reduce downgrade attacks."
  },
  cookie_flag_analysis: {
    title: "Cookie flag analysis",
    desc: "Reviews Set-Cookie flags (Secure, HttpOnly, SameSite). Missing flags may weaken session protection and increase XSS/CSRF risk."
  },
  information_disclosure_headers: {
    title: "Information disclosure headers",
    desc: "Detects headers like Server or X-Powered-By that may reveal technology versions and help attackers fingerprint targets."
  },
  sensitive_path_accessibility: {
    title: "Sensitive path checks",
    desc: "Attempts non-intrusive access to common sensitive paths (.env, .git, admin endpoints). Accessible resources may expose configuration or internal data."
  },
  http_methods_enumeration: {
    title: "HTTP methods enumeration",
    desc: "Uses OPTIONS/Allow to detect risky HTTP methods (PUT/DELETE/TRACE). Dangerous methods can enable unintended behavior on some servers."
  },
  directory_listing_detection: {
    title: "Directory listing detection",
    desc: "Checks common directories for listing indicators like 'Index of /'. Directory listing can expose files, backups, logs, or uploads."
  },
  basic_reflected_input_check: {
    title: "Basic reflected input check",
    desc: "Adds a benign marker parameter and checks if it's reflected in the response. Reflection may indicate weak output encoding and potential injection risk."
  },
  tls_certificate_check: {
    title: "TLS certificate check",
    desc: "Reads certificate metadata (expiry/issuer) for HTTPS targets. TLS errors or misconfiguration can impact confidentiality."
  }
};

function setStatus(msg) {
  statusBox.classList.remove("hidden");
  statusBox.textContent = msg;
}

function setLoading(on) {
  if (on) {
    overlay.classList.remove("hidden");
    btnSpinner.classList.remove("hidden");
    runBtn.disabled = true;
    setStatus("Running scan…");
  } else {
    overlay.classList.add("hidden");
    btnSpinner.classList.add("hidden");
    runBtn.disabled = false;
  }
}

function badge(status) {
  const s = (status || "").toUpperCase();
  const cls = s === "PASS" ? "pass" : s === "WARN" ? "warn" : s === "FAIL" ? "fail" : "err";
  return `<span class="badge ${cls}">${s}</span>`;
}

function countStatuses(report) {
  let pass = 0, warn = 0, fail = 0, err = 0;

  function inc(s) {
    if (!s) return;
    s = s.toUpperCase();
    if (s === "PASS") pass++;
    else if (s === "WARN") warn++;
    else if (s === "FAIL") fail++;
    else if (s === "ERROR") err++;
  }

  const checks = report.checks || {};
  for (const v of Object.values(checks)) {
    if (v && Array.isArray(v.findings)) {
      v.findings.forEach(f => inc(f.status));
    } else if (v && typeof v.status === "string") {
      inc(v.status);
    }
  }
  return { pass, warn, fail, err };
}

function renderSummary(report) {
  const sum = countStatuses(report);
  const items = [
    { label: "Pass", count: sum.pass, status: "PASS" },
    { label: "Warnings", count: sum.warn, status: "WARN" },
    { label: "Fails", count: sum.fail, status: "FAIL" },
    { label: "Errors", count: sum.err, status: "ERROR" }
  ];

  summaryBox.innerHTML = items.map(i => `
    <div class="summaryItem">
      <div class="summaryLeft">
        ${badge(i.status)}
        <div class="summaryLabel">${i.label}</div>
      </div>
      <div class="summaryCount">${i.count}</div>
    </div>
  `).join("");
}

function formatKV(data) {
  // Small key/value chips: status + a few helpful attributes
  const kv = [];
  if (data?.status) kv.push(["Status", data.status]);
  if (data?.final_url) kv.push(["Final URL", data.final_url]);
  if (data?.allowed?.length) kv.push(["Allowed", data.allowed.join(", ")]);
  if (data?.risky?.length) kv.push(["Risky", data.risky.join(", ")]);
  if (data?.notAfter) kv.push(["Cert expiry", data.notAfter]);

  return kv.length
    ? `<div class="kv">${kv.map(([k,v]) => `<span><b>${k}:</b> ${escapeHtml(String(v))}</span>`).join("")}</div>`
    : "";
}

function escapeHtml(s) {
  return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

function renderDetails(report) {
  const checks = report.checks || {};
  let html = "";

  for (const [key, data] of Object.entries(checks)) {
    const info = CHECK_INFO[key] || { title: key.replaceAll("_", " "), desc: "" };
    const rawJson = JSON.stringify(data, null, 2);

    html += `
      <div class="detailCard">
        <div class="detailTop">
          <div class="detailTitle">
            <h3>${escapeHtml(info.title)}</h3>
            <p class="detailDesc">${escapeHtml(info.desc)}</p>
          </div>

          <div class="detailActions">
            <button class="smallBtn" data-action="toggle" data-key="${escapeHtml(key)}">Read more</button>
            <button class="smallBtn" data-action="copy" data-key="${escapeHtml(key)}">Copy JSON</button>
          </div>
        </div>

        ${formatKV(data)}

        <div class="detailBody hidden" id="body_${escapeHtml(key)}">
          <div class="raw">
            <pre>${escapeHtml(rawJson)}</pre>
          </div>
        </div>
      </div>
    `;
  }

  detailsBox.innerHTML = html;

  // attach handlers
  detailsBox.querySelectorAll("button[data-action]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const action = btn.getAttribute("data-action");
      const key = btn.getAttribute("data-key");
      const data = checks[key];
      const raw = JSON.stringify(data, null, 2);

      if (action === "toggle") {
        const el = document.getElementById(`body_${key}`);
        const isHidden = el.classList.contains("hidden");
        el.classList.toggle("hidden");
        btn.textContent = isHidden ? "Hide" : "Read more";
      }

      if (action === "copy") {
        const ok = await copyText(raw);
        btn.textContent = ok ? "Copied!" : "Copy failed";
        setTimeout(() => (btn.textContent = "Copy JSON"), 1200);
      }
    });
  });
}

function renderScore(report, reportFile) {
  const s = report.score?.value ?? 0;
  scoreBox.textContent = `${s}/100`;
  ratingBox.textContent = `Rating: ${report.score?.rating || "N/A"}`;

  downloadBox.innerHTML = reportFile
    ? `Download JSON report: <a href="/api/report/${encodeURIComponent(reportFile)}">${escapeHtml(reportFile)}</a>`
    : "";

  const d = report.score?.deductions || [];
  if (!d.length) {
    deductionsBox.innerHTML = `<div>No deductions. Great configuration.</div>`;
    return;
  }

  const top = d.slice(0, 6); // show top few
  deductionsBox.innerHTML = `
    <div><b>Top deductions</b></div>
    <ul>
      ${top.map(x => `<li>-${x.points} — ${escapeHtml(x.reason)}</li>`).join("")}
    </ul>
  `;
}

runBtn.addEventListener("click", async () => {
  const url = urlInput.value.trim();
  if (!url) {
    setStatus("Please enter a website URL.");
    return;
  }

  resultsBox.classList.add("hidden");
  setLoading(true);

  try {
    const res = await fetch("/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });

    const payload = await res.json();
    if (!res.ok) {
      setLoading(false);
      setStatus(payload.error || "Scan failed.");
      return;
    }

    const report = payload.report;
    const file = payload.report_file;

    renderScore(report, file);
    renderSummary(report);
    renderDetails(report);

    setLoading(false);
    setStatus("Scan complete.");
    resultsBox.classList.remove("hidden");
  } catch (e) {
    setLoading(false);
    setStatus("Error: " + e.message);
  }
});
