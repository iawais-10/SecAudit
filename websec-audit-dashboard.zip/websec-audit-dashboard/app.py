from flask import Flask, render_template, request, jsonify, send_file
from scanner import run_scan
from scoring import compute_score
import os
import json
from datetime import datetime

app = Flask(__name__)

REPORT_DIR = os.path.join(os.path.dirname(__file__), "reports")
os.makedirs(REPORT_DIR, exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/scan", methods=["POST"])
def api_scan():
    data = request.get_json(force=True)
    url = (data.get("url") or "").strip()

    if not url:
        return jsonify({"error": "URL is required"}), 400

    # Run scan
    report = run_scan(url)

    # Score
    score = compute_score(report)
    report["score"] = score

    # Save JSON report
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    safe_name = report.get("target", {}).get("host", "report").replace(":", "_")
    filename = f"security_report_{safe_name}_{timestamp}.json"
    filepath = os.path.join(REPORT_DIR, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
        

    return jsonify({
        "report": report,
        "report_file": filename
    })

@app.route("/api/report/<path:filename>", methods=["GET"])
def download_report(filename):
    filepath = os.path.join(REPORT_DIR, filename)
    if not os.path.isfile(filepath):
        return jsonify({"error": "Report not found"}), 404
    return send_file(filepath, as_attachment=True)

if __name__ == "__main__":
    # run: python app.py
    app.run(host="127.0.0.1", port=5000, debug=True)
