def compute_score(report: dict) -> dict:
    checks = report.get("checks", {})
    score = 100
    deductions = []

    def deduct(points: int, reason: str):
        nonlocal score
        score -= points
        deductions.append({"points": points, "reason": reason})

    # 1) Security headers
    hdr = checks.get("security_headers_audit", {})
    for f in hdr.get("findings", []):
        if f.get("status") == "FAIL":
            deduct(4, f"Missing security header: {f.get('header')}")

    # 2) HTTPS redirect + HSTS
    https = checks.get("https_redirect_and_hsts", {})
    if https.get("http_to_https_redirect", {}).get("status") in ["WARN", "FAIL"]:
        deduct(10, "HTTP does not reliably redirect to HTTPS")
    if https.get("hsts", {}).get("status") == "FAIL":
        deduct(10, "HSTS missing")

    # 3) Cookies
    cookies = checks.get("cookie_flag_analysis", {})
    for c in cookies.get("findings", []):
        if c.get("status") == "WARN":
            deduct(3, "Cookie missing recommended flags (Secure/HttpOnly/SameSite)")

    # 4) Info disclosure
    info = checks.get("information_disclosure_headers", {})
    for f in info.get("findings", []):
        if f.get("status") == "WARN":
            deduct(2, f"Information disclosure header present: {f.get('header')}")

    # 5) Sensitive paths
    sp = checks.get("sensitive_path_accessibility", {})
    for f in sp.get("findings", []):
        if f.get("status") == "WARN":
            deduct(5, f"Sensitive path accessible: {f.get('path')}")

    # 6) HTTP methods
    m = checks.get("http_methods_enumeration", {})
    if m.get("status") == "WARN":
        deduct(8, f"Risky HTTP methods enabled: {', '.join(m.get('risky', []))}")

    # 7) Directory listing
    dl = checks.get("directory_listing_detection", {})
    for f in dl.get("findings", []):
        if f.get("status") == "FAIL":
            deduct(12, f"Directory listing detected: {f.get('path')}")

    # 8) Reflected input
    ri = checks.get("basic_reflected_input_check", {})
    if ri.get("status") == "WARN":
        deduct(8, "Reflected input detected (potential input handling weakness)")

    # 9) TLS cert check (only deduct on HTTPS failures)
    tls = checks.get("tls_certificate_check", {})
    if tls.get("status") == "ERROR":
        deduct(6, "TLS certificate check failed (HTTPS issue or handshake error)")

    # clamp
    if score < 0:
        score = 0
    if score > 100:
        score = 100

    # rating label
    if score >= 90:
        rating = "Excellent"
    elif score >= 75:
        rating = "Good"
    elif score >= 55:
        rating = "Fair"
    else:
        rating = "Poor"

    return {"value": score, "rating": rating, "deductions": deductions}
